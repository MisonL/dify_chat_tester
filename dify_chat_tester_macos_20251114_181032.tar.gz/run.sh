#!/bin/bash
# 获取脚本所在目录
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# 切换到脚本目录并运行
cd "$DIR"
./dify_chat_tester
